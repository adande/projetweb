Chat module for dolibarr ERP.

Current supported languages : ENG / FR.

![Screenshot](screenshot.png)

feel free to contact me if you need any further information.
